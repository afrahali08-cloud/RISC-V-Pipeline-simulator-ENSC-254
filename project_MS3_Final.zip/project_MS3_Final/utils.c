#include "utils.h"
#include <stdio.h>
#include <stdlib.h>

/* Unpacks the 32-bit machine code instruction given into the correct
 * type within the instruction struct */
Instruction parse_instruction(uint32_t instruction_bits) {
  Instruction instruction;
  instruction.bits = instruction_bits;
  instruction.opcode = instruction_bits & 0x7F;
  uint32_t remaining = instruction_bits >> 7;
 
  switch (instruction.opcode) {
  // R-Type
  case 0x33:
    instruction.rtype.rd     = remaining & 0x1F; remaining >>= 5;
    instruction.rtype.funct3 = remaining & 0x7;  remaining >>= 3;
    instruction.rtype.rs1    = remaining & 0x1F; remaining >>= 5;
    instruction.rtype.rs2    = remaining & 0x1F; remaining >>= 5;
    instruction.rtype.funct7 = remaining & 0x7F;
    break;
 
  // I-Type (immediate ALU)
  case 0x13:
  // I-Type (loads)
  case 0x03:
  // I-Type (ecall)
  case 0x73:
    instruction.itype.rd     = remaining & 0x1F; remaining >>= 5;
    instruction.itype.funct3 = remaining & 0x7;  remaining >>= 3;
    instruction.itype.rs1    = remaining & 0x1F; remaining >>= 5;
    instruction.itype.imm    = remaining & 0xFFF;
    break;
 
  // S-Type
  case 0x23:
    instruction.stype.imm5  = remaining & 0x1F; remaining >>= 5;
    instruction.stype.funct3= remaining & 0x7;  remaining >>= 3;
    instruction.stype.rs1   = remaining & 0x1F; remaining >>= 5;
    instruction.stype.rs2   = remaining & 0x1F; remaining >>= 5;
    instruction.stype.imm7  = remaining & 0x7F;
    break;
 
  // SB-Type (branches)
  case 0x63:
    instruction.sbtype.imm5  = remaining & 0x1F; remaining >>= 5;
    instruction.sbtype.funct3= remaining & 0x7;  remaining >>= 3;
    instruction.sbtype.rs1   = remaining & 0x1F; remaining >>= 5;
    instruction.sbtype.rs2   = remaining & 0x1F; remaining >>= 5;
    instruction.sbtype.imm7  = remaining & 0x7F;
    break;
 
  // U-Type (lui)
  case 0x37:
    instruction.utype.rd  = remaining & 0x1F; remaining >>= 5;
    instruction.utype.imm = remaining & 0xFFFFF;
    break;
 
  // UJ-Type (jal)
  case 0x6F:
    instruction.ujtype.rd  = remaining & 0x1F; remaining >>= 5;
    instruction.ujtype.imm = remaining & 0xFFFFF;
    break;
 
#ifndef TESTING
  default:
    exit(EXIT_FAILURE);
#endif
  }
  return instruction;
}

/************************Helper functions************************/
/* Here, you will need to implement a few common helper functions, 
 * which you will call in other functions when parsing, printing, 
 * or executing the instructions. */

/* Sign extends the given field to a 32-bit integer where field is
 * interpreted an n-bit integer. */
int sign_extend_number(unsigned int field, unsigned int n) {
  // If the top bit (bit n-1) is set, fill upper bits with 1s
  if (field & (1U << (n - 1))) {
    return (int)(field | (~0U << n));
  }
  return (int)field;
}

/* Return the number of bytes (from the current PC) to the branch label using
 * the given branch instruction */
int get_branch_offset(Instruction instruction) {
  // SB-type immediate encoding:
  // imm[12|10:5] in imm7 (bits [6:0] of imm7 field)
  // imm[4:1|11]  in imm5 (bits [4:0] of imm5 field)
  // bit layout: imm7[6]=imm[12], imm7[5:0]=imm[10:5], imm5[4]=imm[11], imm5[3:0]=imm[4:1]
  unsigned int imm7 = instruction.sbtype.imm7;
  unsigned int imm5 = instruction.sbtype.imm5;
 
  unsigned int imm12 = (imm7 >> 6) & 0x1;       // bit 12
  unsigned int imm11 = imm5 & 0x1;               // bit 11
  unsigned int imm10_5 = imm7 & 0x3F;            // bits 10:5
  unsigned int imm4_1 = (imm5 >> 1) & 0xF;       // bits 4:1
 
  unsigned int offset = (imm12 << 12) | (imm11 << 11) | (imm10_5 << 5) | (imm4_1 << 1);
  return sign_extend_number(offset, 13);
}

/* Returns the number of bytes (from the current PC) to the jump label using the
 * given jump instruction */
int get_jump_offset(Instruction instruction) {
  // UJ-type immediate encoding in the imm field (20 bits):
  // instruction bits [31:12] = rd(5) + imm(20)
  // After extracting: ujtype.imm holds bits [31:12] of the instruction (the 20-bit imm field)
  // The imm field bits: [19]=imm[20], [18:11]=imm[10:1], [10]=imm[11], [9:0]=imm[19:12]
  unsigned int imm = instruction.ujtype.imm;
 
  unsigned int imm20   = (imm >> 19) & 0x1;        // bit 20
  unsigned int imm19_12= imm & 0xFF;                // bits 19:12
  unsigned int imm11   = (imm >> 8) & 0x1;          // bit 11
  unsigned int imm10_1 = (imm >> 9) & 0x3FF;        // bits 10:1
 
  unsigned int offset = (imm20 << 20) | (imm19_12 << 12) | (imm11 << 11) | (imm10_1 << 1);
  return sign_extend_number(offset, 21);
}

/* Returns the number of bytes (from the current PC) to the base address using the
 * given store instruction */
int get_store_offset(Instruction instruction) {
  // S-type: imm[11:5] in imm7, imm[4:0] in imm5
  unsigned int offset = (instruction.stype.imm7 << 5) | instruction.stype.imm5;
  return sign_extend_number(offset, 12);
}
/************************Helper functions************************/

void handle_invalid_instruction(Instruction instruction) {
  printf("Invalid Instruction: 0x%08x\n", instruction.bits);
}

void handle_invalid_read(Address address) {
  printf("Bad Read. Address: 0x%08x\n", address);
  exit(-1);
}

void handle_invalid_write(Address address) {
  printf("Bad Write. Address: 0x%08x\n", address);
  exit(-1);
}
