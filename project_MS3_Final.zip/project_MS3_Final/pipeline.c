#include <stdbool.h>
#include "cache.h"
#include "riscv.h"
#include "types.h"
#include "utils.h"
#include "pipeline.h"
#include "stage_helpers.h"

uint64_t total_cycle_counter = 0;
uint64_t miss_count = 0;
uint64_t hit_count = 0;
uint64_t stall_counter = 0;
uint64_t branch_counter = 0;
uint64_t fwd_exex_counter = 0;
uint64_t fwd_exmem_counter = 0;

simulator_config_t sim_config = {0};

///////////////////////////////////////////////////////////////////////////////

void bootstrap(
  pipeline_wires_t* pwires_p,
  pipeline_regs_t* pregs_p,
  regfile_t* regfile_p
)
{
  // PC source must get the same value as the default PC value
  pwires_p->pc_src0 = regfile_p->PC;
  pwires_p->pc_src1 = 0;
  pwires_p->pcsrc = false;

  // Start all pipeline registers as empty
  pregs_p->ifid_preg.inp = (ifid_reg_t){0};
  pregs_p->ifid_preg.out = (ifid_reg_t){0};

  pregs_p->idex_preg.inp = (idex_reg_t){0};
  pregs_p->idex_preg.out = (idex_reg_t){0};

  pregs_p->exmem_preg.inp = (exmem_reg_t){0};
  pregs_p->exmem_preg.out = (exmem_reg_t){0};

  pregs_p->memwb_preg.inp = (memwb_reg_t){0};
  pregs_p->memwb_preg.out = (memwb_reg_t){0};
}

///////////////////////////
/// STAGE FUNCTIONALITY ///
///////////////////////////

/**
 * STAGE  : stage_fetch
 * output : ifid_reg_t
 **/
ifid_reg_t stage_fetch(
  pipeline_wires_t* pwires_p,
  regfile_t* regfile_p,
  Byte* memory_p
)
{
  ifid_reg_t ifid_reg = {0};

  uint32_t current_pc;

  /*
   * Select either:
   * pc_src0 = normal PC
   * pc_src1 = branch or jump target
   */
  if (pwires_p->pcsrc)
  {
    current_pc = pwires_p->pc_src1;
    pwires_p->pcsrc = false;
  }
  else
  {
    current_pc = pwires_p->pc_src0;
  }

uint32_t instruction_bits =
  load(memory_p, current_pc, LENGTH_WORD);

/* Treat empty instruction memory as a RISC-V NOP */
if (instruction_bits == 0)
{
  instruction_bits = 0x00000013;
}

ifid_reg.instr = parse_instruction(instruction_bits);

#ifdef DEBUG_CYCLE
printf(
  "[IF ]: Instruction [%08x]@[%08x]: ",
  instruction_bits,
  current_pc
);

decode_instruction(instruction_bits);
#endif

  ifid_reg.instr_addr = current_pc;

  // Default next instruction is PC + 4
  regfile_p->PC = current_pc + 4;
  pwires_p->pc_src0 = regfile_p->PC;

  return ifid_reg;
}

/**
 * STAGE  : stage_decode
 * output : idex_reg_t
 **/
idex_reg_t stage_decode(
  ifid_reg_t ifid_reg,
  pipeline_wires_t* pwires_p,
  regfile_t* regfile_p
)
{
  idex_reg_t idex_reg = {0};

  (void)pwires_p;

  #ifdef DEBUG_CYCLE
  printf(
    "[ID ]: Instruction [%08x]@[%08x]: ",
    ifid_reg.instr.bits,
    ifid_reg.instr_addr
  );
  decode_instruction(ifid_reg.instr.bits);
  #endif

  if (ifid_reg.instr.bits == 0)
  {
    return idex_reg;
  }

  // Generate the control signals
  idex_reg = gen_control(ifid_reg.instr);

  // Pass instruction information into the next stage
  idex_reg.instr = ifid_reg.instr;
  idex_reg.instr_addr = ifid_reg.instr_addr;

  // Generate immediate value
  idex_reg.imm = gen_imm(ifid_reg.instr);

  switch (ifid_reg.instr.opcode)
  {
    case 0x33: // R-type
      idex_reg.rs1 = ifid_reg.instr.rtype.rs1;
      idex_reg.rs2 = ifid_reg.instr.rtype.rs2;
      idex_reg.rd = ifid_reg.instr.rtype.rd;
      break;

    case 0x13: // I-type arithmetic
    case 0x03: // load
      idex_reg.rs1 = ifid_reg.instr.itype.rs1;
      idex_reg.rd = ifid_reg.instr.itype.rd;
      break;

    case 0x23: // store
      idex_reg.rs1 = ifid_reg.instr.stype.rs1;
      idex_reg.rs2 = ifid_reg.instr.stype.rs2;
      break;

    case 0x63: // branch
      idex_reg.rs1 = ifid_reg.instr.sbtype.rs1;
      idex_reg.rs2 = ifid_reg.instr.sbtype.rs2;
      break;

    case 0x37: // lui
      idex_reg.rd = ifid_reg.instr.utype.rd;
      break;

    case 0x6F: // jal
      idex_reg.rd = ifid_reg.instr.ujtype.rd;
      break;

    case 0x73: // ecall
      break;

    default:
      break;
  }

  // Read source register values
  idex_reg.rs1_val = regfile_p->R[idex_reg.rs1];
  idex_reg.rs2_val = regfile_p->R[idex_reg.rs2];

  return idex_reg;
}

/**
 * STAGE  : stage_execute
 * output : exmem_reg_t
 **/
exmem_reg_t stage_execute(
  idex_reg_t idex_reg,
  pipeline_wires_t* pwires_p
)
{
  exmem_reg_t exmem_reg = {0};

  (void)pwires_p;

  #ifdef DEBUG_CYCLE
  printf(
    "[EX ]: Instruction [%08x]@[%08x]: ",
    idex_reg.instr.bits,
    idex_reg.instr_addr
  );
  decode_instruction(idex_reg.instr.bits);
  #endif

  if (idex_reg.instr.bits == 0)
  {
    return exmem_reg;
  }

  // Pass instruction information forward
  exmem_reg.instr = idex_reg.instr;
  exmem_reg.instr_addr = idex_reg.instr_addr;

  // Pass register and control values forward
  exmem_reg.rd = idex_reg.rd;
  exmem_reg.rs2_val = idex_reg.rs2_val;

  exmem_reg.reg_write = idex_reg.reg_write;
  exmem_reg.mem_read = idex_reg.mem_read;
  exmem_reg.mem_write = idex_reg.mem_write;
  exmem_reg.mem_to_reg = idex_reg.mem_to_reg;
  exmem_reg.jump = idex_reg.jump;

  /*
   * JAL:
   * rd receives the address of the next instruction.
   * The new PC is the current instruction address plus the jump offset.
   */
  if (idex_reg.jump)
  {
    exmem_reg.alu_result = idex_reg.instr_addr + 4;

    exmem_reg.branch_target =
      idex_reg.instr_addr + idex_reg.imm;

    exmem_reg.branch_taken = true;

    return exmem_reg;
  }

  /*
   * Conditional branch
   */
  if (idex_reg.branch)
  {
    exmem_reg.branch_target =
      idex_reg.instr_addr + idex_reg.imm;

    exmem_reg.branch_taken = gen_branch(
      idex_reg.instr,
      idex_reg.rs1_val,
      idex_reg.rs2_val
    );

    return exmem_reg;
  }

  uint32_t alu_inp1 = idex_reg.rs1_val;
  uint32_t alu_inp2;

  if (idex_reg.alu_src)
  {
    alu_inp2 = idex_reg.imm;
  }
  else
  {
    alu_inp2 = idex_reg.rs2_val;
  }

  uint32_t alu_control = gen_alu_control(idex_reg);

  exmem_reg.alu_result = execute_alu(
    alu_inp1,
    alu_inp2,
    alu_control
  );

  return exmem_reg;
}

/**
 * STAGE  : stage_mem
 * output : memwb_reg_t
 **/
memwb_reg_t stage_mem(
  exmem_reg_t exmem_reg,
  pipeline_wires_t* pwires_p,
  Byte* memory_p,
  Cache* cache_p
)
{
  memwb_reg_t memwb_reg = {0};

  // Cache is not used for Milestone 1
  (void)cache_p;

  #ifdef DEBUG_CYCLE
  printf(
    "[MEM]: Instruction [%08x]@[%08x]: ",
    exmem_reg.instr.bits,
    exmem_reg.instr_addr
  );
  decode_instruction(exmem_reg.instr.bits);
  #endif

  if (exmem_reg.instr.bits == 0)
  {
    return memwb_reg;
  }

  // Pass instruction information forward
  memwb_reg.instr = exmem_reg.instr;
  memwb_reg.instr_addr = exmem_reg.instr_addr;

  // Pass writeback information forward
  memwb_reg.rd = exmem_reg.rd;
  memwb_reg.reg_write = exmem_reg.reg_write;
  memwb_reg.mem_to_reg = exmem_reg.mem_to_reg;
  memwb_reg.alu_result = exmem_reg.alu_result;

  /*
   * Load instructions
   */
  if (exmem_reg.mem_read)
  {
    switch (exmem_reg.instr.itype.funct3)
    {
      case 0x0: // lb
      {
        uint32_t value =
          load(
            memory_p,
            exmem_reg.alu_result,
            LENGTH_BYTE
          );

        memwb_reg.mem_data =
          (uint32_t)(int32_t)(int8_t)value;

        break;
      }

      case 0x1: // lh
      {
        uint32_t value =
          load(
            memory_p,
            exmem_reg.alu_result,
            LENGTH_HALF_WORD
          );

        memwb_reg.mem_data =
          (uint32_t)(int32_t)(int16_t)value;

        break;
      }

      case 0x2: // lw
        memwb_reg.mem_data =
          load(
            memory_p,
            exmem_reg.alu_result,
            LENGTH_WORD
          );
        break;

      default:
        memwb_reg.mem_data = 0;
        break;
    }
  }

  /*
   * Store instructions
   *
   * Memory is written directly here because store() in emulator.c
   * is currently unfinished.
   */
  if (exmem_reg.mem_write)
  {
    uint32_t address = exmem_reg.alu_result;
    uint32_t value = exmem_reg.rs2_val;

    switch (exmem_reg.instr.stype.funct3)
    {
      case 0x0: // sb
        memory_p[address] =
          (Byte)(value & 0xFF);
        break;

      case 0x1: // sh
        memory_p[address] =
          (Byte)(value & 0xFF);

        memory_p[address + 1] =
          (Byte)((value >> 8) & 0xFF);
        break;

      case 0x2: // sw
        memory_p[address] =
          (Byte)(value & 0xFF);

        memory_p[address + 1] =
          (Byte)((value >> 8) & 0xFF);

        memory_p[address + 2] =
          (Byte)((value >> 16) & 0xFF);

        memory_p[address + 3] =
          (Byte)((value >> 24) & 0xFF);
        break;

      default:
        break;
    }
  }

  /*
   * Redirect the PC after a taken branch or JAL.
   */
  if (exmem_reg.branch_taken)
  {
    pwires_p->pc_src1 = exmem_reg.branch_target;
    pwires_p->pcsrc = true;

    branch_counter++;
  }

  return memwb_reg;
}

/**
 * STAGE  : stage_writeback
 * output : nothing - The state of the register file may be changed
 **/
void stage_writeback(
  memwb_reg_t memwb_reg,
  pipeline_wires_t* pwires_p,
  regfile_t* regfile_p
)
{
  (void)pwires_p;

  #ifdef DEBUG_CYCLE
  printf(
    "[WB ]: Instruction [%08x]@[%08x]: ",
    memwb_reg.instr.bits,
    memwb_reg.instr_addr
  );
  decode_instruction(memwb_reg.instr.bits);
  #endif

  if (
    memwb_reg.reg_write &&
    memwb_reg.rd != 0
  )
  {
    if (memwb_reg.mem_to_reg)
    {
      regfile_p->R[memwb_reg.rd] =
        memwb_reg.mem_data;
    }
    else
    {
      regfile_p->R[memwb_reg.rd] =
        memwb_reg.alu_result;
    }
  }

  // x0 must always remain zero
  regfile_p->R[0] = 0;
}

///////////////////////////////////////////////////////////////////////////////

/**
 * excite the pipeline with one clock cycle
 **/
void cycle_pipeline(
  regfile_t* regfile_p,
  Byte* memory_p,
  Cache* cache_p,
  pipeline_regs_t* pregs_p,
  pipeline_wires_t* pwires_p,
  bool* ecall_exit
)
{
  #ifdef DEBUG_CYCLE
  printf("v==============");
  printf(
    "Cycle Counter = %5ld",
    total_cycle_counter
  );
  printf("==============v\n\n");
  #endif

  // Process each stage

  /* Output               |    Stage      |       Inputs  */
  pregs_p->ifid_preg.inp  =
    stage_fetch(
      pwires_p,
      regfile_p,
      memory_p
    );

  pregs_p->idex_preg.inp  =
    stage_decode(
      pregs_p->ifid_preg.out,
      pwires_p,
      regfile_p
    );

  pregs_p->exmem_preg.inp =
    stage_execute(
      pregs_p->idex_preg.out,
      pwires_p
    );

  pregs_p->memwb_preg.inp =
    stage_mem(
      pregs_p->exmem_preg.out,
      pwires_p,
      memory_p,
      cache_p
    );

  stage_writeback(
    pregs_p->memwb_preg.out,
    pwires_p,
    regfile_p
  );

  // Update all pipeline-register outputs
  pregs_p->ifid_preg.out =
    pregs_p->ifid_preg.inp;

  pregs_p->idex_preg.out =
    pregs_p->idex_preg.inp;

  pregs_p->exmem_preg.out =
    pregs_p->exmem_preg.inp;

  pregs_p->memwb_preg.out =
    pregs_p->memwb_preg.inp;

  /////////////////// NO CHANGES BELOW THIS ARE REQUIRED //////////////////////

  // Increment the cycle
  total_cycle_counter++;

  #ifdef DEBUG_REG_TRACE
  print_register_trace(regfile_p);
  #endif

  /*
   * Check the ecall condition.
   */
  if (
    (pregs_p->memwb_preg.out.instr.bits == 0x00000073) &&
    (regfile_p->R[10] == 10)
  )
  {
    *(ecall_exit) = true;
  }
}