#ifndef __STAGE_HELPERS_H__
#define __STAGE_HELPERS_H__

#include <stdio.h>
#include <stdint.h>
#include "utils.h"
#include "pipeline.h"

/// EXECUTE STAGE HELPERS ///

/**
 * input  : idex_reg_t
 * output : uint32_t alu_control signal
 **/
uint32_t gen_alu_control(idex_reg_t idex_reg)
{
  Instruction instruction = idex_reg.instr;

  switch (instruction.opcode)
  {
    case 0x33: // R-type
      switch (instruction.rtype.funct3)
      {
        case 0x0:
          if (instruction.rtype.funct7 == 0x20)
          {
            return 0x1; // sub
          }
          else if (instruction.rtype.funct7 == 0x01)
          {
            return 0x9; // mul
          }
          else
          {
            return 0x0; // add
          }

        case 0x1:
          if (instruction.rtype.funct7 == 0x01)
          {
            return 0xA; // mulh
          }
          else
          {
            return 0x2; // sll
          }

        case 0x2:
          return 0x3; // slt

        case 0x4:
          if (instruction.rtype.funct7 == 0x01)
          {
            return 0xB; // div
          }
          else
          {
            return 0x4; // xor
          }

        case 0x5:
          if (instruction.rtype.funct7 == 0x20)
          {
            return 0x6; // sra
          }
          else
          {
            return 0x5; // srl
          }

        case 0x6:
          if (instruction.rtype.funct7 == 0x01)
          {
            return 0xC; // rem
          }
          else
          {
            return 0x7; // or
          }

        case 0x7:
          return 0x8; // and

        default:
          return 0x0;
      }

    case 0x13: // I-type
      switch (instruction.itype.funct3)
      {
        case 0x0:
          return 0x0; // addi

        case 0x1:
          return 0x2; // slli

        case 0x2:
          return 0x3; // slti

        case 0x4:
          return 0x4; // xori

        case 0x5:
          if (((instruction.itype.imm >> 5) & 0x7F) == 0x20)
          {
            return 0x6; // srai
          }
          else
          {
            return 0x5; // srli
          }

        case 0x6:
          return 0x7; // ori

        case 0x7:
          return 0x8; // andi

        default:
          return 0x0;
      }

    case 0x03: // load
      return 0x0; // address = rs1 + immediate

    case 0x23: // store
      return 0x0; // address = rs1 + immediate

    case 0x37: // lui
      return 0xD; // pass immediate

    default:
      return 0x0;
  }
}

/**
 * input  : alu_inp1, alu_inp2, alu_control
 * output : uint32_t alu_result
 **/
uint32_t execute_alu(
  uint32_t alu_inp1,
  uint32_t alu_inp2,
  uint32_t alu_control
)
{
  uint32_t result;

  switch (alu_control)
  {
    case 0x0: // add
      result = alu_inp1 + alu_inp2;
      break;

    case 0x1: // sub
      result = alu_inp1 - alu_inp2;
      break;

    case 0x2: // sll
      result = alu_inp1 << (alu_inp2 & 0x1F);
      break;

    case 0x3: // slt
      result =
        ((int32_t)alu_inp1 < (int32_t)alu_inp2)
        ? 1
        : 0;
      break;

    case 0x4: // xor
      result = alu_inp1 ^ alu_inp2;
      break;

    case 0x5: // srl
      result = alu_inp1 >> (alu_inp2 & 0x1F);
      break;

    case 0x6: // sra
      result =
        (uint32_t)(
          (int32_t)alu_inp1 >>
          (alu_inp2 & 0x1F)
        );
      break;

    case 0x7: // or
      result = alu_inp1 | alu_inp2;
      break;

    case 0x8: // and
      result = alu_inp1 & alu_inp2;
      break;

    case 0x9: // mul
    {
      int64_t product =
        (int64_t)(int32_t)alu_inp1 *
        (int64_t)(int32_t)alu_inp2;

      result = (uint32_t)product;
      break;
    }

    case 0xA: // mulh
    {
      int64_t product =
        (int64_t)(int32_t)alu_inp1 *
        (int64_t)(int32_t)alu_inp2;

      result = (uint32_t)(product >> 32);
      break;
    }

    case 0xB: // div
      if (alu_inp2 == 0)
      {
        result = 0xFFFFFFFF;
      }
      else if (
        alu_inp1 == 0x80000000 &&
        alu_inp2 == 0xFFFFFFFF
      )
      {
        result = 0x80000000;
      }
      else
      {
        result =
          (uint32_t)(
            (int32_t)alu_inp1 /
            (int32_t)alu_inp2
          );
      }
      break;

    case 0xC: // rem
      if (alu_inp2 == 0)
      {
        result = alu_inp1;
      }
      else if (
        alu_inp1 == 0x80000000 &&
        alu_inp2 == 0xFFFFFFFF
      )
      {
        result = 0;
      }
      else
      {
        result =
          (uint32_t)(
            (int32_t)alu_inp1 %
            (int32_t)alu_inp2
          );
      }
      break;

    case 0xD: // pass immediate for lui
      result = alu_inp2;
      break;

    default:
      result = 0xBADCAFFE;
      break;
  }

  return result;
}

/// DECODE STAGE HELPERS ///

/**
 * input  : Instruction
 * output : uint32_t immediate
 **/
uint32_t gen_imm(Instruction instruction)
{
  int32_t imm_val = 0;

  switch (instruction.opcode)
  {
    case 0x13: // I-type arithmetic
      imm_val =
        sign_extend_number(
          instruction.itype.imm,
          12
        );
      break;

    case 0x03: // load
      imm_val =
        sign_extend_number(
          instruction.itype.imm,
          12
        );
      break;

    case 0x23: // S-type store
      imm_val =
        get_store_offset(instruction);
      break;

    case 0x63: // B-type branch
      imm_val =
        get_branch_offset(instruction);
      break;

    case 0x37: // lui
      imm_val =
        instruction.utype.imm << 12;
      break;

    case 0x6F: // jal
      imm_val =
        get_jump_offset(instruction);
      break;

    default:
      imm_val = 0;
      break;
  }

  return (uint32_t)imm_val;
}

/**
 * generates all the control logic that flows around in the pipeline
 * input  : Instruction
 * output : idex_reg_t
 **/
idex_reg_t gen_control(Instruction instruction)
{
  idex_reg_t idex_reg = {0};

  switch (instruction.opcode)
  {
    case 0x33: // R-type
      idex_reg.reg_write = true;
      idex_reg.mem_read = false;
      idex_reg.mem_write = false;
      idex_reg.mem_to_reg = false;
      idex_reg.alu_src = false;
      idex_reg.branch = false;
      idex_reg.jump = false;
      idex_reg.lui = false;
      break;

    case 0x13: // I-type arithmetic
      idex_reg.reg_write = true;
      idex_reg.mem_read = false;
      idex_reg.mem_write = false;
      idex_reg.mem_to_reg = false;
      idex_reg.alu_src = true;
      idex_reg.branch = false;
      idex_reg.jump = false;
      idex_reg.lui = false;
      break;

    case 0x03: // load
      idex_reg.reg_write = true;
      idex_reg.mem_read = true;
      idex_reg.mem_write = false;
      idex_reg.mem_to_reg = true;
      idex_reg.alu_src = true;
      idex_reg.branch = false;
      idex_reg.jump = false;
      idex_reg.lui = false;
      break;

    case 0x23: // store
      idex_reg.reg_write = false;
      idex_reg.mem_read = false;
      idex_reg.mem_write = true;
      idex_reg.mem_to_reg = false;
      idex_reg.alu_src = true;
      idex_reg.branch = false;
      idex_reg.jump = false;
      idex_reg.lui = false;
      break;

    case 0x63: // branch
      idex_reg.reg_write = false;
      idex_reg.mem_read = false;
      idex_reg.mem_write = false;
      idex_reg.mem_to_reg = false;
      idex_reg.alu_src = false;
      idex_reg.branch = true;
      idex_reg.jump = false;
      idex_reg.lui = false;
      break;

    case 0x37: // lui
      idex_reg.reg_write = true;
      idex_reg.mem_read = false;
      idex_reg.mem_write = false;
      idex_reg.mem_to_reg = false;
      idex_reg.alu_src = true;
      idex_reg.branch = false;
      idex_reg.jump = false;
      idex_reg.lui = true;
      break;

    case 0x6F: // jal
      idex_reg.reg_write = true;
      idex_reg.mem_read = false;
      idex_reg.mem_write = false;
      idex_reg.mem_to_reg = false;
      idex_reg.alu_src = false;
      idex_reg.branch = false;
      idex_reg.jump = true;
      idex_reg.lui = false;
      break;

    case 0x73: // ecall
      idex_reg.reg_write = false;
      idex_reg.mem_read = false;
      idex_reg.mem_write = false;
      idex_reg.mem_to_reg = false;
      idex_reg.alu_src = false;
      idex_reg.branch = false;
      idex_reg.jump = false;
      idex_reg.lui = false;
      break;

    default:
      break;
  }

  return idex_reg;
}

/// MEMORY STAGE HELPERS ///

/**
 * evaluates whether a branch must be taken
 * input  : Instruction, rs1 value, rs2 value
 * output : bool
 **/
bool gen_branch(
  Instruction instruction,
  uint32_t rs1_val,
  uint32_t rs2_val
)
{
  switch (instruction.sbtype.funct3)
  {
    case 0x0: // beq
      return rs1_val == rs2_val;

    case 0x1: // bne
      return rs1_val != rs2_val;

    default:
      return false;
  }
}


/// PIPELINE FEATURES ///

/**
 * Task   : Sets the pipeline wires for the forwarding unit's control signals
 *          based on the pipeline register values.
 * input  : pipeline_regs_t*, pipeline_wires_t*
 * output : None
 **/
void gen_forward(
  pipeline_regs_t* pregs_p,
  pipeline_wires_t* pwires_p
)
{
  /*
   * Forwarding is implemented in Milestone 2.
   * Milestone 1 assumes NOPs prevent hazards.
   */
  (void)pregs_p;
  (void)pwires_p;
}

/**
 * Task   : Sets the pipeline wires for the hazard unit's control signals
 *          based on the pipeline register values.
 * input  : pipeline_regs_t*, pipeline_wires_t*
 * output : None
 **/
void detect_hazard(
  pipeline_regs_t* pregs_p,
  pipeline_wires_t* pwires_p,
  regfile_t* regfile_p
)
{
  /*
   * Hazard detection is implemented in Milestone 2.
   * Milestone 1 assumes NOPs prevent hazards.
   */
  (void)pregs_p;
  (void)pwires_p;
  (void)regfile_p;
}


///////////////////////////////////////////////////////////////////////////////

/// RESERVED FOR PRINTING REGISTER TRACE AFTER EACH CLOCK CYCLE ///
void print_register_trace(regfile_t* regfile_p)
{
  for (uint8_t i = 0; i < 8; i++)
  {
    for (uint8_t j = 0; j < 4; j++)
    {
      printf(
        "r%2d=%08x ",
        i * 4 + j,
        regfile_p->R[i * 4 + j]
      );
    }

    printf("\n");
  }

  printf("\n");
}

#endif // __STAGE_HELPERS_H__
